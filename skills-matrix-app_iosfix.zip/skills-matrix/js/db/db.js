/**
 * DB — IndexedDB wrapper. Pure I/O, zero domain logic.
 * All methods return Promises.
 */
const DB = (() => {
  const NAME = 'SkillsMatrixDB';
  const VERSION = 3;
  let _db = null;

  const SCHEMA = [
    { name: 'lines',        opts: { keyPath: 'id', autoIncrement: true },  indexes: [] },
    { name: 'employees',    opts: { keyPath: 'id', autoIncrement: true },
      indexes: [
        { name: 'lineId',        kp: 'lineId',                    opts: {} },
        { name: 'role',          kp: 'role',                      opts: {} },
        { name: 'lineRole',      kp: ['lineId','role'],           opts: {} },
        { name: 'lineActive',    kp: ['lineId','active'],         opts: {} },
        { name: 'lineNormName',  kp: ['lineId','normalizedName'], opts: { unique: true } },
      ]
    },
    { name: 'positions',    opts: { keyPath: 'id', autoIncrement: true },
      indexes: [
        { name: 'lineId',        kp: 'lineId',                    opts: {} },
        { name: 'lineCritical',  kp: ['lineId','critical'],       opts: {} },
        { name: 'lineNormName',  kp: ['lineId','normalizedName'], opts: { unique: true } },
      ]
    },
    { name: 'skillRecords', opts: { keyPath: 'id', autoIncrement: true },
      indexes: [
        { name: 'lineId',      kp: 'lineId',                         opts: {} },
        { name: 'employeeId',  kp: 'employeeId',                     opts: {} },
        { name: 'positionId',  kp: 'positionId',                     opts: {} },
        { name: 'empPos',      kp: ['employeeId','positionId'],       opts: { unique: true } },
      ]
    },
    { name: 'trainingLogs', opts: { keyPath: 'id', autoIncrement: true },
      indexes: [
        { name: 'lineId',              kp: 'lineId',                         opts: {} },
        { name: 'employeeId',          kp: 'employeeId',                     opts: {} },
        { name: 'positionId',          kp: 'positionId',                     opts: {} },
        { name: 'timestamp',           kp: 'timestamp',                      opts: {} },
        { name: 'lineTimestamp',       kp: ['lineId','timestamp'],           opts: {} },
        { name: 'lineServerReceived',  kp: ['lineId','serverReceivedAt'],    opts: {} },
        { name: 'syncedToAuthority',   kp: 'syncedToAuthority',             opts: {} },
        { name: 'clientId',            kp: 'clientId',                       opts: { unique: true } },
        { name: 'employeeResolved',    kp: 'employeeResolved',               opts: {} },
      ]
    },
    { name: 'attendance',   opts: { keyPath: 'id', autoIncrement: true },
      indexes: [
        { name: 'lineId',       kp: 'lineId',                  opts: {} },
        { name: 'employeeId',   kp: 'employeeId',              opts: {} },
        { name: 'date',         kp: 'date',                    opts: {} },
        { name: 'empDate',      kp: ['employeeId','date'],     opts: { unique: true } },
        { name: 'lineDate',     kp: ['lineId','date'],         opts: {} },
      ]
    },
    { name: 'rotationPlans',opts: { keyPath: 'id', autoIncrement: true },
      indexes: [
        { name: 'lineId',    kp: 'lineId',           opts: {} },
        { name: 'date',      kp: 'date',             opts: {} },
        { name: 'lineDate',  kp: ['lineId','date'],  opts: {} },
      ]
    },
    { name: 'auditLogs',    opts: { keyPath: 'id', autoIncrement: true },
      indexes: [
        { name: 'lineId',       kp: 'lineId',                    opts: {} },
        { name: 'positionId',   kp: 'positionId',                opts: {} },
        { name: 'supervisorId', kp: 'supervisorId',              opts: {} },
        { name: 'date',         kp: 'date',                      opts: {} },
        { name: 'supDate',      kp: ['supervisorId','date'],     opts: {} },
        { name: 'lineSuper',    kp: ['lineId','supervisorId'],   opts: {} },
      ]
    },
    { name: 'templateMappings', opts: { keyPath: 'id', autoIncrement: true },
      indexes: [
        { name: 'lineId', kp: 'lineId', opts: { unique: true } },
      ]
    },
    { name: 'pendingRecommendations', opts: { keyPath: 'id', autoIncrement: true },
      indexes: [
        { name: 'lineId',      kp: 'lineId',                    opts: {} },
        { name: 'employeeId',  kp: 'employeeId',                opts: {} },
        { name: 'positionId',  kp: 'positionId',                opts: {} },
        { name: 'status',      kp: 'status',                    opts: {} },
        { name: 'lineStatus',  kp: ['lineId','status'],         opts: {} },
        { name: 'empPos',      kp: ['employeeId','positionId'], opts: {} },
        { name: 'clientId',    kp: 'clientId',                  opts: { unique: true } },
        { name: 'syncedToAuthority', kp: 'syncedToAuthority',  opts: {} },
      ]
    },
    { name: 'users',        opts: { keyPath: 'id', autoIncrement: true },
      indexes: [
        { name: 'role',   kp: 'role',   opts: {} },
        { name: 'active', kp: 'active', opts: {} },
      ]
    },
    { name: 'devices',      opts: { keyPath: 'id' },
      indexes: [
        { name: 'role',   kp: 'role',   opts: {} },
        { name: 'lineId', kp: 'lineId', opts: {} },
      ]
    },
    { name: 'appSettings',  opts: { keyPath: 'key' }, indexes: [] },
  ];

  function open() {
    return new Promise((resolve, reject) => {
      if (_db) { resolve(_db); return; }
      // Some iOS/WebKit contexts (notably file:// or restricted browser modes)
      // can hang on indexedDB.open() without firing success/error.
      // We add: (1) guards for missing/throwing indexedDB, (2) onblocked, and
      // (3) a timeout so the UI can show a readable message instead of spinning.
      if (typeof indexedDB === 'undefined') {
        reject(new Error('IndexedDB is not available in this browser context.'));
        return;
      }

      let req;
      try {
        req = indexedDB.open(NAME, VERSION);
      } catch (err) {
        reject(err);
        return;
      }

      const timer = setTimeout(() => {
        reject(new Error('IndexedDB open timed out. This can happen on iOS when running from a file:// URL or when storage is blocked.'));
      }, 6000);
      req.onupgradeneeded = e => {
        const d = e.target.result;
        const tx = e.target.transaction;
        SCHEMA.forEach(s => {
          let store;
          if (!d.objectStoreNames.contains(s.name)) {
            store = d.createObjectStore(s.name, s.opts);
          } else {
            store = tx.objectStore(s.name);
          }
          s.indexes.forEach(idx => {
            if (!store.indexNames.contains(idx.name)) {
              try { store.createIndex(idx.name, idx.kp, idx.opts); } catch(e) {}
            }
          });
        });
      };
      req.onblocked = () => {
        clearTimeout(timer);
        reject(new Error('IndexedDB upgrade blocked. Close other tabs/windows running this app and try again.'));
      };

      req.onsuccess = e => {
        clearTimeout(timer);
        _db = e.target.result;
        // If a newer version is requested in another tab, close cleanly.
        _db.onversionchange = () => {
          try { _db.close(); } catch (e) {}
          _db = null;
        };
        resolve(_db);
      };

      req.onerror = e => {
        clearTimeout(timer);
        reject(e.target.error || new Error('IndexedDB open failed.'));
      };
    });
  }

  function _store(name, mode) {
    return _db.transaction(name, mode).objectStore(name);
  }

  function get(store, key) {
    return open().then(() => new Promise((res, rej) => {
      const r = _store(store).get(key);
      r.onsuccess = e => res(e.target.result);
      r.onerror   = e => rej(e.target.error);
    }));
  }

  function getAll(store) {
    return open().then(() => new Promise((res, rej) => {
      const r = _store(store).getAll();
      r.onsuccess = e => res(e.target.result);
      r.onerror   = e => rej(e.target.error);
    }));
  }

  function getAllByIndex(store, indexName, query) {
    return open().then(() => new Promise((res, rej) => {
      const r = _store(store).index(indexName).getAll(query);
      r.onsuccess = e => res(e.target.result);
      r.onerror   = e => rej(e.target.error);
    }));
  }

  function getByIndex(store, indexName, query) {
    return open().then(() => new Promise((res, rej) => {
      const r = _store(store).index(indexName).get(query);
      r.onsuccess = e => res(e.target.result);
      r.onerror   = e => rej(e.target.error);
    }));
  }

  function put(store, data) {
    return open().then(() => new Promise((res, rej) => {
      const r = _store(store, 'readwrite').put(data);
      r.onsuccess = e => res(e.target.result);
      r.onerror   = e => rej(e.target.error);
    }));
  }

  function add(store, data) {
    return open().then(() => new Promise((res, rej) => {
      const r = _store(store, 'readwrite').add(data);
      r.onsuccess = e => res(e.target.result);
      r.onerror   = e => rej(e.target.error);
    }));
  }

  function remove(store, key) {
    return open().then(() => new Promise((res, rej) => {
      const r = _store(store, 'readwrite').delete(key);
      r.onsuccess = e => res(e.target.result);
      r.onerror   = e => rej(e.target.error);
    }));
  }

  function clear(store) {
    return open().then(() => new Promise((res, rej) => {
      const r = _store(store, 'readwrite').clear();
      r.onsuccess = e => res(e.target.result);
      r.onerror   = e => rej(e.target.error);
    }));
  }

  async function getSetting(key, defaultVal = null) {
    const rec = await get('appSettings', key);
    return rec !== undefined ? rec.value : defaultVal;
  }

  function setSetting(key, value) {
    return put('appSettings', { key, value });
  }

  /** Upsert attendance record by empDate unique index */
  async function upsertAttendance(data) {
    await open();
    return new Promise((res, rej) => {
      const tx = _db.transaction('attendance', 'readwrite');
      const store = tx.objectStore('attendance');
      const idx = store.index('empDate');
      const findReq = idx.getKey(IDBKeyRange.only([data.employeeId, data.date]));
      findReq.onsuccess = e => {
        const existingKey = e.target.result;
        const record = existingKey ? { ...data, id: existingKey } : data;
        const putReq = store.put(record);
        putReq.onsuccess = ev => res(ev.target.result);
        putReq.onerror   = ev => rej(ev.target.error);
      };
      findReq.onerror = e => rej(e.target.error);
    });
  }

  /** Batch upsert attendance for a whole day in one transaction */
  async function batchUpsertAttendance(records) {
    await open();
    return new Promise((res, rej) => {
      const tx = _db.transaction('attendance', 'readwrite');
      const store = tx.objectStore('attendance');
      const idx = store.index('empDate');
      let pending = records.length;
      if (!pending) { res([]); return; }
      const results = [];

      records.forEach(data => {
        const findReq = idx.getKey(IDBKeyRange.only([data.employeeId, data.date]));
        findReq.onsuccess = e => {
          const existingKey = e.target.result;
          const record = existingKey ? { ...data, id: existingKey } : data;
          const putReq = store.put(record);
          putReq.onsuccess = ev => { results.push(ev.target.result); };
        };
      });

      tx.oncomplete = () => res(results);
      tx.onerror    = e  => rej(e.target.error);
    });
  }

  /** Upsert by a unique index (generic) */
  async function upsertByIndex(storeName, indexName, keyValue, data) {
    await open();
    return new Promise((res, rej) => {
      const tx = _db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const idx = store.index(indexName);
      const query = Array.isArray(keyValue) ? IDBKeyRange.only(keyValue) : keyValue;
      const findReq = idx.getKey(query);
      findReq.onsuccess = e => {
        const existingKey = e.target.result;
        const record = existingKey !== undefined ? { ...data, id: existingKey } : data;
        const putReq = store.put(record);
        putReq.onsuccess = ev => res(ev.target.result);
        putReq.onerror   = ev => rej(ev.target.error);
      };
      findReq.onerror = e => rej(e.target.error);
    });
  }

  /** Get all records sorted by a field */
  async function getAllSorted(store, sortFn) {
    const all = await getAll(store);
    return all.sort(sortFn);
  }

  return {
    open, get, getAll, getAllByIndex, getByIndex, put, add, remove, clear,
    getSetting, setSetting, upsertAttendance, batchUpsertAttendance, upsertByIndex,
    getAllSorted, NAME
  };
})();
