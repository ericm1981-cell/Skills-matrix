/**
 * App — Bootstrap, router, sidebar renderer, init.
 */
const App = (() => {

  let _deviceRole   = 'authority';
  let _deviceLineId = null;
  let _currentPage  = 'dashboard';
  let _qrLineId     = null;

  // ── Nav config ──────────────────────────────────────────────────
  const NAV_AUTHORITY = [
    { section: 'nav_section_overview', items: [
      { id: 'dashboard',     icon: '◈', label: 'nav_dashboard' },
    ]},
    { section: 'nav_section_skills', items: [
      { id: 'matrix',        icon: '⊞', label: 'nav_matrix' },
      { id: 'approvals',     icon: '✓', label: 'nav_approvals', badge: 'pendingCount' },
      { id: 'cross',         icon: '⟷', label: 'nav_cross' },
    ]},
    { section: 'nav_section_ops', items: [
      { id: 'rotation',      icon: '↻', label: 'nav_rotation' },
      { id: 'attendance',    icon: '☑', label: 'nav_attendance' },
      { id: 'audits',        icon: '⊛', label: 'nav_audits' },
    ]},
    { section: 'nav_section_data', items: [
      { id: 'importExport',  icon: '⇅', label: 'nav_import_export' },
      { id: 'qr',            icon: '⬛', label: 'nav_qr' },
      { id: 'reports',       icon: '≡', label: 'nav_reports' },
      { id: 'sync',          icon: '⇌', label: 'nav_sync' },
      { id: 'setup',         icon: '⚙', label: 'nav_setup' },
    ]},
  ];

  const NAV_FIELD = [
    { section: 'nav_section_overview', items: [
      { id: 'qrForm',        icon: '✎', label: 'nav_dashboard' },
      { id: 'sync',          icon: '⇌', label: 'nav_sync' },
    ]},
  ];

  // ── Init ────────────────────────────────────────────────────────
  async function init() {
    // iOS/WebKit can sometimes hang on IndexedDB open (especially on file://
    // or when storage is restricted). Use a hard timeout so we never spin forever.
    try {
      await Promise.race([
        DB.open(),
        new Promise((_, reject) => setTimeout(() => {
          reject(new Error('Startup timed out while opening local storage (IndexedDB). On iPhone, try: (1) not Private mode, (2) open from the Files app and choose “Open in Safari”, or (3) clear site data for this file context and retry.'));
        }, 8000))
      ]);
    } catch (err) {
      _renderFatal(err);
      return;
    }

    // Language
    try {
      const lang = await DB.getSetting('language', 'en');
      window._LANG = lang;
    } catch (err) {
      _renderFatal(err);
      return;
    }

    // Device role
    try {
      _deviceRole   = await DB.getSetting('deviceRole', 'authority');
      _deviceLineId = await DB.getSetting('deviceLineId', null);
    } catch (err) {
      _renderFatal(err);
      return;
    }

    // Check QR param
    const params = new URLSearchParams(window.location.search);
    _qrLineId = params.get('qr') ? parseInt(params.get('qr')) : null;

    // Load global data
    await lineService.loadAll();
    await lineService.loadUsers();

    // If field device, set active line
    if (_deviceRole === 'field' && _deviceLineId) {
      await lineService.loadLineData(_deviceLineId);
    }

    // Render shell
    _renderShell();

    // Handle routing
    if (_deviceRole === 'field') {
      if (!_deviceLineId) {
        _showProvisionPage();
        return;
      }
      const session = Session.get();
      _currentPage = 'qrForm';
      _renderNav();
      await _renderPage('qrForm');
    } else if (_qrLineId) {
      // Authority opened a QR link — show form for that line
      await lineService.loadLineData(_qrLineId);
      AppState.lines.forEach(l => {}); // ensure lines loaded
      _renderNav();
      _currentPage = 'qrForm';
      await _renderPage('qrForm');
    } else {
      // Authority normal boot
      const firstLine = AppState.lines[0];
      if (firstLine) {
        await lineService.loadLineData(firstLine.id);
      }
      _renderNav();
      _renderSidebarLineSelector();
      await navigate('dashboard');
    }

    _applyLang();
  }

  function _renderFatal(err) {
    const msg = (err && (err.stack || err.message)) ? (err.stack || err.message) : String(err);
    const esc = (s) => String(s)
      .replaceAll('&','&amp;')
      .replaceAll('<','&lt;')
      .replaceAll('>','&gt;')
      .replaceAll('"','&quot;')
      .replaceAll("'",'&#39;');
    const el = document.getElementById('app');
    if (!el) return;
    el.innerHTML = `
      <div style="min-height:100vh; background:#0b0b0b; color:#e8e8e8; font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial; padding:16px;">
        <div style="max-width:760px; margin:0 auto;">
          <h1 style="margin:0 0 8px 0;">Skills Matrix</h1>
          <div style="border:1px solid #2a2a2a; border-radius:14px; padding:14px; background:#121212;">
            <h2 style="margin:0 0 8px 0; font-size:16px;">Startup error</h2>
            <p style="margin:0 0 10px 0; opacity:.9;">The app couldn't start on this browser context.</p>
            <pre style="white-space:pre-wrap; word-break:break-word; font-size:12px; line-height:1.35; padding:10px; background:#0b0b0b; border:1px solid #2a2a2a; border-radius:10px;">${esc(msg)}</pre>
            <div style="margin-top:10px; font-size:13px; opacity:.9;">
              <div><b>Try this on iPhone:</b></div>
              <ul style="margin:6px 0 0 18px;">
                <li>Turn off Private browsing.</li>
                <li>Open from the <b>Files</b> app → Share → <b>Open in Safari</b>.</li>
                <li>If it still hangs, delete any older copy of the folder/zip and re-extract fully.</li>
              </ul>
            </div>
            <div style="margin-top:12px; display:flex; gap:10px; flex-wrap:wrap;">
              <button id="sm-reload" style="padding:10px 12px; border-radius:12px; border:1px solid #444; background:#1a1a1a; color:#fff;">Reload</button>
              <button id="sm-info" style="padding:10px 12px; border-radius:12px; border:1px solid #444; background:#1a1a1a; color:#fff;">Device info</button>
            </div>
            <pre id="sm-diag" style="display:none; margin-top:10px; white-space:pre-wrap; word-break:break-word; font-size:12px; line-height:1.35; padding:10px; background:#0b0b0b; border:1px solid #2a2a2a; border-radius:10px;"></pre>
          </div>
        </div>
      </div>
    `;
    const r = document.getElementById('sm-reload');
    if (r) r.onclick = () => location.reload();
    const b = document.getElementById('sm-info');
    if (b) b.onclick = () => {
      const d = document.getElementById('sm-diag');
      if (!d) return;
      d.style.display = 'block';
      d.textContent = [
        `userAgent: ${navigator.userAgent}`,
        `url: ${location.href}`,
        `indexedDB: ${typeof indexedDB}`,
      ].join('\n');
    };
  }

  // ── Shell ───────────────────────────────────────────────────────
  function _renderShell() {
    document.getElementById('app').innerHTML = `
      <div class="app-shell" id="app-shell">

        <nav class="sidebar" id="sidebar">
          <div class="sidebar-logo">
            <div class="logo-mark">SM</div>
            <span class="logo-text">SkillOps</span>
          </div>
          <div class="sidebar-line-selector" id="line-selector-wrap"></div>
          <nav class="sidebar-nav" id="sidebar-nav"></nav>
          <div class="sidebar-footer">
            <div class="lang-toggle">
              <button class="lang-btn ${window._LANG==='en'?'active':''}" data-lang="en">EN</button>
              <button class="lang-btn ${window._LANG==='es'?'active':''}" data-lang="es">ES</button>
            </div>
            <div class="session-info" id="session-info-footer"></div>
          </div>
        </nav>

        <header class="topbar" id="topbar">
          <span class="topbar-title" id="topbar-title">SkillOps</span>
          <div class="topbar-actions">
            <span class="device-badge ${_deviceRole}" id="device-badge">${t(_deviceRole)}</span>
          </div>
        </header>

        <main class="main-content" id="main">
          <div id="page-content"></div>
        </main>
      </div>
      <div id="toast-container"></div>`;

    // Language buttons
    document.getElementById('sidebar').addEventListener('click', e => {
      const btn = e.target.closest('[data-lang]');
      if (!btn) return;
      const lang = btn.dataset.lang;
      window._LANG = lang;
      DB.setSetting('language', lang);
      document.querySelectorAll('.lang-btn').forEach(b => b.classList.toggle('active', b.dataset.lang === lang));
      _renderNav();
      _renderSidebarLineSelector();
      _refreshPageTitle();
      _reloadCurrentPage();
    });
  }

  // ── Sidebar nav ─────────────────────────────────────────────────
  function renderSidebar() {
    _renderNav();
    _renderSidebarLineSelector();
    _updateSessionFooter();
  }

  function _renderNav() {
    const nav = document.getElementById('sidebar-nav');
    if (!nav) return;

    const navConfig = _deviceRole === 'field' ? NAV_FIELD : NAV_AUTHORITY;
    const pendingCount = AppState.skillRecords.filter(r => r.status === 'pending_dual').length;

    let html = '';
    navConfig.forEach(group => {
      html += `<div class="nav-section-label">${t(group.section)}</div>`;
      group.items.forEach(item => {
        const badge = item.badge === 'pendingCount' && pendingCount > 0
          ? `<span class="nav-badge">${pendingCount}</span>` : '';
        html += `<a class="nav-item${_currentPage === item.id ? ' active' : ''}"
          data-page="${item.id}" href="#" role="button">
          <span class="nav-icon">${item.icon}</span>
          <span>${t(item.label)}</span>
          ${badge}
        </a>`;
      });
    });
    nav.innerHTML = html;

    nav.addEventListener('click', e => {
      const link = e.target.closest('[data-page]');
      if (!link) return;
      e.preventDefault();
      navigate(link.dataset.page);
    });
  }

  function _renderSidebarLineSelector() {
    const wrap = document.getElementById('line-selector-wrap');
    if (!wrap || _deviceRole === 'field') { if (wrap) wrap.style.display = 'none'; return; }

    const lines = AppState.lines;
    if (!lines.length) { wrap.innerHTML = ''; return; }

    wrap.innerHTML = `<select id="line-selector">
      <option value="">${t('select_line')}…</option>
      ${lines.map(l => `<option value="${l.id}"${l.id === AppState.currentLineId ? ' selected' : ''}>${l.name}</option>`).join('')}
    </select>`;

    document.getElementById('line-selector').addEventListener('change', async e => {
      const lineId = parseInt(e.target.value);
      if (!lineId) return;
      await lineService.loadLineData(lineId);
      _renderNav();
      _reloadCurrentPage();
    });
  }

  function _updateSessionFooter() {
    const el = document.getElementById('session-info-footer');
    if (!el) return;
    const session = Session.get();
    if (session) {
      el.innerHTML = `<span class="session-name">${session.name}</span><span style="font-size:9px;color:var(--text-3)">${t('role_'+session.role)}</span>`;
    } else {
      el.innerHTML = '';
    }
  }

  // ── Router ───────────────────────────────────────────────────────
  async function navigate(page) {
    _currentPage = page;

    // Update active nav
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.page === page);
    });

    _refreshPageTitle();
    await _renderPage(page);
    _updateSessionFooter();

    // Scroll to top
    document.getElementById('main')?.scrollTo(0, 0);
  }

  async function _renderPage(page) {
    document.getElementById('page-content').innerHTML =
      `<div style="padding:var(--sp-6);color:var(--text-3);font-family:var(--font-mono);font-size:12px">${t('loading')}</div>`;

    try {
      if (page === 'qrForm') {
        const lineId = _qrLineId || _deviceLineId || AppState.currentLineId;
        if (!lineId) { document.getElementById('page-content').innerHTML = _noLine(); return; }
        const employees = await DB.getAllByIndex('employees', 'lineId', lineId);
        const positions = await DB.getAllByIndex('positions', 'lineId', lineId);
        await Pages.qrForm(lineId, { employees: employees.filter(e => e.active !== false), positions });
      } else if (Pages[page]) {
        await Pages[page]();
      } else {
        document.getElementById('page-content').innerHTML = `<div class="empty-state">Page not found: ${page}</div>`;
      }
    } catch(e) {
      console.error(`[page:${page}]`, e);
      document.getElementById('page-content').innerHTML =
        `<div class="info-box error">Error loading page: ${e.message}<br><pre style="font-size:10px;margin-top:8px;color:var(--text-3)">${e.stack||''}</pre></div>`;
    }
  }

  function _refreshPageTitle() {
    const titleMap = {
      dashboard: 'page_dashboard', matrix: 'page_matrix', approvals: 'page_approvals',
      cross: 'page_cross', rotation: 'page_rotation', attendance: 'page_attendance',
      audits: 'page_audits', importExport: 'page_import_export', qr: 'page_qr',
      reports: 'page_reports', sync: 'page_sync', setup: 'page_setup', qrForm: 'log_training'
    };
    const key = titleMap[_currentPage] || 'app_name';
    const titleEl = document.getElementById('topbar-title');
    if (titleEl) titleEl.textContent = t(key);
  }

  function _reloadCurrentPage() {
    navigate(_currentPage);
  }

  function _applyLang() {
    applyTranslations(document);
  }

  // ── Provision page (field, unprovisioned) ────────────────────────
  function _showProvisionPage() {
    document.getElementById('app').innerHTML = `
      <div class="overlay-page">
        <div class="overlay-logo">
          <div class="logo-mark-lg">SM</div>
          <div>
            <div class="logo-text-lg">SkillOps</div>
            <div style="font-size:12px;color:var(--text-3);font-family:var(--font-mono)">${t('field')}</div>
          </div>
        </div>
        <div class="card" style="max-width:460px;width:100%">
          <div class="card-header"><span class="card-title">${t('provision_title')}</span></div>
          <div class="card-body">
            <p style="color:var(--text-2);margin-bottom:var(--sp-5)">${t('provision_desc')}</p>
            <div class="upload-zone" id="seed-zone">
              <input type="file" id="seed-file" accept=".json">
              <div class="upload-icon">📱</div>
              <span class="upload-label">${t('provision_load')}</span>
              <span class="upload-hint">${t('provision_hint')}</span>
            </div>
            <div id="prov-status" style="margin-top:var(--sp-4)"></div>
          </div>
        </div>
      </div>
      <div id="toast-container"></div>`;

    const zone  = document.getElementById('seed-zone');
    const input = document.getElementById('seed-file');
    zone.onclick = () => input.click();
    input.onchange = async e => { if (e.target.files[0]) await _doProvision(e.target.files[0]); };
    zone.ondragover = e => { e.preventDefault(); zone.classList.add('drag-over'); };
    zone.ondragleave = () => zone.classList.remove('drag-over');
    zone.ondrop = e => { e.preventDefault(); zone.classList.remove('drag-over'); if (e.dataTransfer.files[0]) _doProvision(e.dataTransfer.files[0]); };
  }

  async function _doProvision(file) {
    const status = document.getElementById('prov-status');
    status.innerHTML = `<div class="info-box">${t('loading')}</div>`;
    try {
      const text = await file.text();
      const seed = JSON.parse(text);
      await syncService.importSeed(seed);
      status.innerHTML = `<div class="info-box success">${t('provision_success')}</div>`;
      setTimeout(() => window.location.reload(), 1200);
    } catch(e) {
      status.innerHTML = `<div class="info-box error">${t('provision_error')}: ${e.message}</div>`;
    }
  }

  // ── Public helpers ───────────────────────────────────────────────
  function setLogger(id, role, name) {
    Session.set(id, role, name);
    _updateSessionFooter();
    _reloadCurrentPage();
  }

  // Expose fatal renderer for global traps
  return { init, navigate, renderSidebar, setLogger, __fatal: _renderFatal };
})();

// ── Entry point ──────────────────────────────────────────────────────
function _noLine() {
  return `<div class="empty-state"><div class="empty-icon">⚙</div><p>${t('no_line_selected')}</p></div>`;
}

document.addEventListener('DOMContentLoaded', () => {
  // Global error traps so iOS failures don't look like "infinite loading"
  window.addEventListener('error', (e) => {
    try { App && App.__fatal && App.__fatal(e.error || new Error(e.message || 'Unknown error')); } catch(_) {}
  });
  window.addEventListener('unhandledrejection', (e) => {
    try { App && App.__fatal && App.__fatal(e.reason || new Error('Unhandled promise rejection')); } catch(_) {}
  });

  App.init().catch(e => {
    console.error('[App.init]', e);
    try { App && App.__fatal ? App.__fatal(e) : null; } catch(_) {
      document.body.innerHTML = `<div style="padding:40px;font-family:monospace;color:#ef4444">
        <h2>Startup Error</h2><pre>${e && (e.stack || e.message) ? (e.stack || e.message) : String(e)}</pre>
      </div>`;
    }
  });
});
